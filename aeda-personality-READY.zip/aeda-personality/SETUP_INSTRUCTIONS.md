# AEDA Personality App — Deployment Guide

## Step 1: Set up Supabase (free database — 5 mins)

1. Go to https://supabase.com and click "Start your project"
2. Sign in with GitHub or Google
3. Click "New Project"
   - Name: aeda-personality
   - Database password: choose something strong (save it)
   - Region: Sydney (ap-southeast-2)
4. Wait ~2 minutes for project to spin up
5. Go to the SQL Editor (left sidebar) and run this query:

CREATE TABLE submissions (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  created_at timestamptz DEFAULT now(),
  name text NOT NULL,
  email text NOT NULL,
  department text,
  result_data jsonb NOT NULL
);

ALTER TABLE submissions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow insert for all" ON submissions FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow select for all" ON submissions FOR SELECT USING (true);
CREATE POLICY "Allow delete for all" ON submissions FOR DELETE USING (true);

6. Go to Project Settings > API
7. Copy:
   - Project URL (looks like: https://xxxx.supabase.co)
   - anon/public key (long string starting with eyJ...)

## Step 2: Deploy to Netlify (free hosting — 5 mins)

1. Go to https://netlify.com and sign up (free)
2. Click "Add new site" > "Deploy manually"
3. You'll need to build the project first OR use Netlify CLI

### Easiest method — Netlify CLI:

1. Install Node.js from https://nodejs.org (if not already installed)
2. Open Terminal and run:
   cd /path/to/aeda-personality
   npm install
   npm run build
3. Drag the "build" folder into Netlify's deploy dropzone at:
   https://app.netlify.com/drop

## Step 3: Add environment variables in Netlify

1. In Netlify, go to Site Settings > Environment Variables
2. Add:
   - REACT_APP_SUPABASE_URL = (your Supabase project URL)
   - REACT_APP_SUPABASE_ANON_KEY = (your Supabase anon key)
3. Go to Deploys > Trigger deploy > Deploy site

## Step 4: Done!
Your app will be live at something like: https://amazing-name-123.netlify.app
Share that link with your team!

## Admin Access
- Go to your live URL
- Scroll to the bottom and click "Admin Access"
- Password: ExpADL@2026
